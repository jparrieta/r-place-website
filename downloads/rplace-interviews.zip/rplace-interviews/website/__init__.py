"""Public documentation and isolated checkpoint interviews, separate from research."""
