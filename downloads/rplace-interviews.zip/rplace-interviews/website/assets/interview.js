(() => {
  const $=id=>document.getElementById(id);let token='',sid=null,poll=null,busy=false,lastMessages='',hosted=false,opening=false;
  // Render only text and basic Markdown structure. Model output is never HTML.
  function inline(parent, value, depth=0) {
    if(depth>12){parent.append(document.createTextNode(value));return;}
    const pattern=/\\([\\`*_[\]{}()#+.!>\-])|`([^`\n]+)`|\*\*([^\n]+?)\*\*|\*([^*\n]+?)\*/g;
    let end=0;
    for(const match of value.matchAll(pattern)){
      parent.append(document.createTextNode(value.slice(end,match.index)));
      if(match[1])parent.append(document.createTextNode(match[1]));
      else {
        const node=document.createElement(match[2]?'code':match[3]?'strong':'em');
        if(match[2])node.textContent=match[2];else inline(node,match[3]||match[4],depth+1);
        parent.append(node);
      }
      end=match.index+match[0].length;
    }
    parent.append(document.createTextNode(value.slice(end)));
  }
  function markdown(value) {
    const root=document.createElement('div');root.className='markdown';
    const lines=String(value).replace(/\r\n?/g,'\n').split('\n');
    const heading=line=>line.match(/^ {0,3}(#{1,6})\s+(.+)$/);
    const bullet=line=>line.match(/^ {0,3}([-+*]|\d+[.)])\s+(.+)$/);
    const fence=line=>line.match(/^ {0,3}(`{3,}|~{3,})[^`]*$/);
    const boundary=line=>heading(line)||bullet(line)||fence(line);
    for(let i=0;i<lines.length;){
      if(!lines[i].trim()){i++;continue;}
      const f=fence(lines[i]),h=heading(lines[i]),b=bullet(lines[i]);
      if(f){
        const marker=f[1],codeLines=[];i++;
        while(i<lines.length){
          const close=lines[i].trim();
          if(close.length>=marker.length&&[...close].every(c=>c===marker[0])){i++;break;}
          codeLines.push(lines[i++]);
        }
        const pre=document.createElement('pre'),code=document.createElement('code');
        code.textContent=codeLines.join('\n');pre.append(code);root.append(pre);continue;
      }
      if(h){const node=document.createElement('h'+Math.max(2,h[1].length));inline(node,h[2]);root.append(node);i++;continue;}
      if(b){
        const ordered=/^\d/.test(b[1]),list=document.createElement(ordered?'ol':'ul');
        if(ordered)list.start=parseInt(b[1],10);
        while(i<lines.length){
          const item=bullet(lines[i]);if(!item||/^\d/.test(item[1])!==ordered)break;
          const text=[item[2]];i++;
          while(i<lines.length&&lines[i].trim()&&!boundary(lines[i])&&/^\s{2,}\S/.test(lines[i]))text.push(lines[i++].trim());
          const li=document.createElement('li');inline(li,text.join('\n'));list.append(li);
        }
        root.append(list);continue;
      }
      const text=[lines[i++]];
      while(i<lines.length&&lines[i].trim()&&!boundary(lines[i]))text.push(lines[i++]);
      const node=document.createElement('p');inline(node,text.join('\n'));root.append(node);
    }
    return root;
  }
  const query=new URLSearchParams(location.search);
  const sessionKey=()=> 'interview-session:'+ $('checkpoint').value;
  function remember(){try{if(sid)sessionStorage.setItem(sessionKey(),sid);else sessionStorage.removeItem(sessionKey());}catch(_){} }
  function showConversation(){
    lastMessages='';remember();
    const url=new URL(location.href);url.searchParams.set('checkpoint',$('checkpoint').value);url.searchParams.set('interview',sid);history.replaceState(null,'',url.pathname+url.search);
    $('identity').textContent='Checkpoint: '+$('checkpoint').selectedOptions[0].textContent;
    $('chooser').hidden=true;$('conversation').hidden=false;
  }
  function watch(){clearInterval(poll);poll=setInterval(()=>refresh().catch(e=>{status('Connection lost. The interview may still be working. '+e.message);$('send').disabled=true;}),2000);}
  const params=new URLSearchParams(location.hash.slice(1));
  try{token=params.get('token')||sessionStorage.getItem('interview-token')||'';}catch(_){}
  history.replaceState(null,'',location.pathname+location.search);$('token').value=token;
  function status(text){$('status').textContent=text;}
  async function api(path,body){
    const r=await fetch(path,{method:body?'POST':'GET',headers:{'Authorization':'Bearer '+token,'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined,cache:'no-store'});
    const data=await r.json();if(!r.ok)throw Error(data.error||'Request failed');return data;
  }
  async function connect(){
    token=$('token').value;const rows=await api('/api/checkpoints');try{sessionStorage.setItem('interview-token',token);}catch(_){}
    $('checkpoint').replaceChildren();rows.forEach(c=>{const o=document.createElement('option');o.value=c.id;o.textContent=c.title;$('checkpoint').append(o);});
    const selected=new URLSearchParams(location.search).get('checkpoint');if(selected&&rows.some(c=>c.id===selected))$('checkpoint').value=selected;
    $('access').hidden=true;$('chooser').hidden=false;status(rows.length?'Choose a checkpoint.':'No checkpoint is admitted yet.');
    $('checkpoint-buttons').replaceChildren();rows.forEach(c=>{const item=document.createElement('article'),heading=document.createElement('h3'),button=document.createElement('button');heading.textContent=c.title;button.textContent='Talk to the agent';button.onclick=()=>{$('checkpoint').value=c.id;openInterview();};item.append(heading,button);$('checkpoint-buttons').append(item);});
    if(selected&&!rows.some(c=>c.id===selected)){status('This checkpoint is not available here. No other checkpoint was opened.');return;}
    let saved=query.get('interview');try{saved=saved||sessionStorage.getItem(sessionKey());}catch(_){}
    if(saved){
      try{
        if(!/^[0-9a-f]{32}$/.test(saved))throw Error('Invalid interview reference.');
        const current=await api('/api/interviews/'+saved);
        if(current.id!==saved||current.checkpoint!==$('checkpoint').value)throw Error('The interview belongs to a different checkpoint.');
        sid=current.id;showConversation();await refresh();watch();
      }catch(e){sid=null;remember();$('conversation').hidden=true;$('chooser').hidden=false;status(e.message+' No new interview was opened.');}
    }else if(selected&&!query.has('closed')){await openInterview();}
  }
  $('access').onsubmit=e=>{e.preventDefault();connect().catch(e=>status(e.message));};
  async function refresh(){
    if(!sid)return;const s=await api('/api/interviews/'+sid);busy=s.status!=='ready';$('send').disabled=busy;$('question').disabled=busy;
    const phases={waiting_restore:'Waiting for another restoration to finish…',restoring_originals:'Restoring and verifying the original files on the interview server…',downloading:'Downloading the saved checkpoint…',unpacking_verifying:'Unpacking and verifying the historical files…',checking_identity:'Checking the saved session identity…',files_ready:'Historical files are ready. Ask a question to open the saved conversation.',opening_conversation:'Opening the saved conversation and preparing a reply…',answering:'The saved analyst is preparing a reply…',ready:'Ready for your question.'};
    status(s.error?'This interview needs the operator’s attention. No replacement agent was started. See Activity and checks below.':(phases[s.phase]||{restoring:'Restoring and checking the historical files…',working:'The saved analyst is preparing a reply…',ready:'Ready for your question.'}[s.status]||s.status));
    const messageState=JSON.stringify(s.messages);
    if(messageState!==lastMessages){lastMessages=messageState;$('interview-log').replaceChildren();s.messages.forEach(m=>{const d=document.createElement('div');d.className='message '+m.role;const label=document.createElement('strong');label.textContent=m.role==='user'?'You':'New checkpoint interview response';let text;if(m.role==='assistant')text=markdown(m.text);else{text=document.createElement('p');text.textContent=m.text;}d.append(label,text);$('interview-log').append(d);});}
    $('activity').textContent=[s.error,...s.events.map(x=>x.summary)].filter(Boolean).join('\n');
  }
  async function openInterview(){if(opening)return;opening=true;try{
    $('checkpoint-buttons').querySelectorAll('button').forEach(b=>b.disabled=true);status('Opening a disposable interview…');const result=await api('/api/interviews',{checkpoint:$('checkpoint').value});sid=result.id;
    showConversation();await refresh();watch();
  }catch(e){status(e.message);}finally{opening=false;$('checkpoint-buttons').querySelectorAll('button').forEach(b=>b.disabled=false);}}
  $('interview-form').onsubmit=async e=>{e.preventDefault();const text=$('question').value;if(text.trim().toLowerCase()==='/exit'){$('question').value='';$('end').click();return;}if(busy)return;try{busy=true;$('send').disabled=true;await api('/api/interviews/'+sid+'/message',{text});$('question').value='';await refresh();}catch(e){status(e.message);busy=false;$('send').disabled=false;}};
  $('export').onclick=async()=>{try{const data=await api('/api/interviews/'+sid+'/export');const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='checkpoint-interview-'+sid+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}catch(e){status(e.message);}};
  $('end').onclick=()=>{$('end-panel').hidden=false;$('end-cancel').focus();};
  $('end-cancel').onclick=()=>{$('end-panel').hidden=true;$('end').focus();};
  $('end-confirm').onclick=async()=>{try{
    $('end-confirm').disabled=true;await api('/api/interviews/'+sid+'/end',{});clearInterval(poll);sid=null;remember();
    const url=new URL(location.href);url.searchParams.delete('interview');url.searchParams.set('closed','1');history.replaceState(null,'',url.pathname+url.search);
    $('conversation').hidden=true;$('chooser').hidden=false;status('Interview closed. Its disposable workspace is being removed.');
  }catch(e){status(e.message);}finally{$('end-confirm').disabled=false;$('end-panel').hidden=true;}};
  async function start(){
    // A hosted gateway keeps its service credential on the server. The browser uses its private cookie.
    if(location.pathname==='/talk'){
      hosted=true;const r=await fetch('/api/hosted-session',{cache:'no-store'});
      if(!r.ok||!(await r.json()).authenticated){location.replace('/login.html'+location.search);return;}
      $('open-interviews-link').hidden=false;
    }
    if(token||hosted)await connect();else{$('access').hidden=false;status('Open your private interview link or enter the access token.');}
  }
  start().catch(e=>{status(e.message);if(!hosted)$('access').hidden=false;});
})();
