# Checkpoint interview launcher

Target length: under 300 words.

This launcher includes the checkpoint catalogue. Research files and saved sessions
are separate downloads. It contains no credentials, models or research controllers.

Use Python 3.11 or newer and the supported Codex or Claude CLI. The catalogue
records tested versions; a different version needs its own compatibility proof.
The website's Chat Locally command verifies and installs this launcher in a private
Python environment, checks access, requests missing sign-ins and opens the interview.
It installs the archive reader when needed. Git, GitHub CLI and the supported provider
CLI must already be installed; the command does not replace them.

Manual setup:

1. Extract this ZIP and open a terminal in `rplace-interviews`.
2. Sign in once with your own account:

   `python3 -m website.interview login codex`

   For Claude checkpoints, replace `codex` with `claude`.
3. Copy the launch command from the checkpoint card. Where an original-source
   recipe is listed, Git retrieves the original commit and verified supplements
   supply only the named missing files. Private repositories need `gh auth login`.
   Other checkpoints use their verified bundle. The launcher opens a private page.
4. Restore the checkpoint and ask a question. Export before ending the interview
   if you want to keep its new responses.

If you already downloaded the bundle, add `--bundle /path/to/bundle.tar.gz` to
the launch command. The same catalogue identity and hash checks still apply.

No model turn begins during restoration. Questions use your account and may
consume its allowance. The historical files stay read-only. Ending removes the
disposable interview files. Cached bundles stay outside this folder in
`~/.rplace-interviews/cache`.

New interviews stay private and are not committed or included in website
releases. Keep exports outside Git repositories. Login and interview homes
inside a Git checkout are rejected.

See `INTERVIEWS.md` and `ORIGINAL-SOURCES.md` for runtime and source details.
